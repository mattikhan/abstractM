package Q3.Buttons;

public interface Button {
    void render();
    void onClick();
}
