public abstract class Geometery {
	public abstract Shape createShape();
}
