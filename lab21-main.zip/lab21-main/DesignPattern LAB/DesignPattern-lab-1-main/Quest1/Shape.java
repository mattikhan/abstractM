public interface Shape {
	void draw();
}
