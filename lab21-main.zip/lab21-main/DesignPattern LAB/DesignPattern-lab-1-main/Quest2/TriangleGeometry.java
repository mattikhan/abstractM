package Q2;

public class TriangleGeometry implements Geometry{
    public void draw(){
        System.out.println("Triangle Drawn");
    }
}
