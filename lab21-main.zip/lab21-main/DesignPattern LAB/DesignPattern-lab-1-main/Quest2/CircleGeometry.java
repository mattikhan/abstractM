package Q2;

public class CircleGeometry implements Geometry {
    public void draw(){
        System.out.println("Circle Drawn");
    }
}
