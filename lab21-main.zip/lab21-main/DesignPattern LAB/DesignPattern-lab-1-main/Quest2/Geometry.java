package Q2;

interface Geometry {
    void draw();
}
