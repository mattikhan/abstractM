package Q2;

public class SquareGeometry implements Geometry {
    public void draw(){
        System.out.println("Square Drawn");
    }
}
